NOTE: This font is for PERSONAL USE ONLY!
But any donation are very appreciated

Paypal account for donation :
anytypeco@gmail.com

FOR EXTENDED LICENSE CONTACT ME : anytypeco@gmail.com

Please visit our store for more great fonts:
https://www.creativefabrica.com/designer/anytypeco/ref/175263/

Follow my Social Media for update : 
https://www.pinterest.com/AnyTypeCo/
https://www.instagram.com/anytypeco/
